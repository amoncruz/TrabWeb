export class Gestor {
    nome: string;
    cargo: string;
    email: string;
    telefone: string;
  }